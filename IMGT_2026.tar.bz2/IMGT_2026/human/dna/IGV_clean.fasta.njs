{
  "version": "1.2",
  "dbname": "IGV_clean.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "IGV_clean.fasta",
  "number-of-letters": 214103,
  "number-of-sequences": 730,
  "last-updated": "2026-03-23T22:46:00",
  "number-of-volumes": 1,
  "bytes-total": 199097,
  "bytes-to-cache": 62949,
  "files": [
    "IGV_clean.fasta.ndb",
    "IGV_clean.fasta.nhr",
    "IGV_clean.fasta.nin",
    "IGV_clean.fasta.nog",
    "IGV_clean.fasta.nos",
    "IGV_clean.fasta.not",
    "IGV_clean.fasta.nsq",
    "IGV_clean.fasta.ntf",
    "IGV_clean.fasta.nto"
  ]
}
