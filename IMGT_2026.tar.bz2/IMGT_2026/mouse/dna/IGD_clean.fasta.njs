{
  "version": "1.2",
  "dbname": "IGD_clean.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "IGD_clean.fasta",
  "number-of-letters": 1141,
  "number-of-sequences": 61,
  "last-updated": "2026-03-24T22:50:00",
  "number-of-volumes": 1,
  "bytes-total": 55788,
  "bytes-to-cache": 1166,
  "files": [
    "IGD_clean.fasta.ndb",
    "IGD_clean.fasta.nhr",
    "IGD_clean.fasta.nin",
    "IGD_clean.fasta.nog",
    "IGD_clean.fasta.nos",
    "IGD_clean.fasta.not",
    "IGD_clean.fasta.nsq",
    "IGD_clean.fasta.ntf",
    "IGD_clean.fasta.nto"
  ]
}
