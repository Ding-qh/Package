{
  "version": "1.2",
  "dbname": "IGV_clean.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "IGV_clean.fasta",
  "number-of-letters": 250682,
  "number-of-sequences": 865,
  "last-updated": "2026-03-24T22:20:00",
  "number-of-volumes": 1,
  "bytes-total": 226596,
  "bytes-to-cache": 73718,
  "files": [
    "IGV_clean.fasta.ndb",
    "IGV_clean.fasta.nhr",
    "IGV_clean.fasta.nin",
    "IGV_clean.fasta.nog",
    "IGV_clean.fasta.nos",
    "IGV_clean.fasta.not",
    "IGV_clean.fasta.nsq",
    "IGV_clean.fasta.ntf",
    "IGV_clean.fasta.nto"
  ]
}
