{
  "version": "1.2",
  "dbname": "IGJ_clean.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "IGJ_clean.fasta",
  "number-of-letters": 1139,
  "number-of-sequences": 27,
  "last-updated": "2026-03-24T22:49:00",
  "number-of-volumes": 1,
  "bytes-total": 52258,
  "bytes-to-cache": 734,
  "files": [
    "IGJ_clean.fasta.ndb",
    "IGJ_clean.fasta.nhr",
    "IGJ_clean.fasta.nin",
    "IGJ_clean.fasta.nog",
    "IGJ_clean.fasta.nos",
    "IGJ_clean.fasta.not",
    "IGJ_clean.fasta.nsq",
    "IGJ_clean.fasta.ntf",
    "IGJ_clean.fasta.nto"
  ]
}
